"""
Задача 14: Flask-сервер — POST CSV → JSON.
Ответ: { valid_count, invalid_count, error_indices (первые 20) }

Запуск : python task_14.py
Тест   : curl -X POST http://localhost:5000/validate \
              -F "file=@marks.csv"
"""
from flask import Flask, request, jsonify
import pandas as pd
import io

app = Flask(__name__)


def _analyse(csv_bytes: bytes) -> dict:
    df = pd.read_csv(io.BytesIO(csv_bytes))

    if "points" not in df.columns:
        raise ValueError("Колонка 'points' не найдена в файле.")

    points_num = pd.to_numeric(df["points"], errors="coerce")
    ok_mask = points_num.notna() & points_num.between(0, 100)

    error_indices = df.index[~ok_mask].tolist()[:20]

    return {
        "valid_count":   int(ok_mask.sum()),
        "invalid_count": int((~ok_mask).sum()),
        "error_indices": error_indices,   # первые 20 плохих индексов (0-based)
    }


@app.route("/validate", methods=["POST"])
def validate():
    if "file" not in request.files:
        return jsonify({"error": "Поле 'file' отсутствует в запросе."}), 400

    file = request.files["file"]
    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Ожидается CSV-файл."}), 400

    try:
        result = _analyse(file.read())
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 422
    except Exception as exc:
        return jsonify({"error": f"Ошибка обработки: {exc}"}), 500

    return jsonify(result), 200


if __name__ == "__main__":
    app.run(debug=True, port=5000)
