"""
Задача 9: Загрузить points в массив, найти индексы, где NaN или вне [0, 100].
"""
import numpy as np
import pandas as pd

df = pd.read_csv("marks.csv")

# Загружаем как float, чтобы NaN сохранился
arr = pd.to_numeric(df["points"], errors="coerce").to_numpy(dtype=float)

# Маска NaN
mask_nan = np.isnan(arr)

# Маска «вне диапазона» (не NaN, но < 0 или > 100)
mask_out = ~mask_nan & ((arr < 0) | (arr > 100))

# Итоговая маска «плохих» строк
mask_bad = mask_nan | mask_out

idx_nan = np.where(mask_nan)[0]
idx_out = np.where(mask_out)[0]
idx_bad = np.where(mask_bad)[0]

print(f"Всего строк       : {len(arr)}")
print(f"NaN-индексы ({len(idx_nan)}): {idx_nan.tolist()}")
print(f"Вне [0,100] ({len(idx_out)}): {idx_out.tolist()}")
print(f"Все плохие ({len(idx_bad)}): {idx_bad.tolist()}")
