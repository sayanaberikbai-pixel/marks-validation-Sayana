"""
Задача 10: На том же массиве — посчитать, сколько строк «хороших» и «плохих».
"""
import numpy as np
import pandas as pd

df = pd.read_csv("marks.csv")
arr = pd.to_numeric(df["points"], errors="coerce").to_numpy(dtype=float)

mask_bad = np.isnan(arr) | (arr < 0) | (arr > 100)
mask_good = ~mask_bad

good_count = int(np.sum(mask_good))
bad_count  = int(np.sum(mask_bad))

print(f"Хороших строк : {good_count}")
print(f"Плохих строк  : {bad_count}")
print(f"Итого         : {good_count + bad_count}")
