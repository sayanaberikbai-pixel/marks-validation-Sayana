"""
Задача 13: Bar-диаграмма: число валидных vs невалидных строк; сохранить PNG.
"""
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

df = pd.read_csv("marks.csv")
points_num = pd.to_numeric(df["points"], errors="coerce")
ok = points_num.notna() & points_num.between(0, 100)

counts = {"Валидные": int(ok.sum()), "Невалидные": int((~ok).sum())}
colors  = ["#2ecc71", "#e74c3c"]

fig, ax = plt.subplots(figsize=(7, 5))
bars = ax.bar(counts.keys(), counts.values(), color=colors, width=0.45,
              edgecolor="white", linewidth=1.5)

for bar, val in zip(bars, counts.values()):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
            str(val), ha="center", va="bottom", fontsize=14, fontweight="bold")

ax.set_title("Проверка баллов: marks.csv", fontsize=15, fontweight="bold", pad=14)
ax.set_ylabel("Количество строк", fontsize=12)
ax.set_ylim(0, max(counts.values()) * 1.18)
ax.spines[["top", "right"]].set_visible(False)
ax.yaxis.grid(True, linestyle="--", alpha=0.5)
ax.set_axisbelow(True)

plt.tight_layout()
plt.savefig("marks_chart.png", dpi=150)
plt.close()
print("Сохранено: marks_chart.png")
