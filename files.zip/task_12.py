"""
Задача 12: Сохранить marks_clean.csv только с валидными строками.
"""
import pandas as pd

df = pd.read_csv("marks.csv")
points_num = pd.to_numeric(df["points"], errors="coerce")

df["ok"] = points_num.notna() & points_num.between(0, 100)

df_clean = df[df["ok"]].drop(columns=["ok"]).reset_index(drop=True)
df_clean.to_csv("marks_clean.csv", index=False)

print(f"Исходных строк : {len(df)}")
print(f"Валидных строк : {len(df_clean)}")
print(f"Сохранено в    : marks_clean.csv")
