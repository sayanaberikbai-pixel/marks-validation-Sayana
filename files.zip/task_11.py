"""
Задача 11: DataFrame с колонкой ok (True/False); вывести первые 10 нарушений.
"""
import pandas as pd

df = pd.read_csv("marks.csv")
points_num = pd.to_numeric(df["points"], errors="coerce")

df["ok"] = points_num.notna() & points_num.between(0, 100)

violations = df[~df["ok"]].head(10)

print("Первые 10 нарушений:")
print(violations.to_string())
print(f"\nВсего нарушений: {(~df['ok']).sum()}")
